import pandas as pd
import datetime as dt
import geopandas as gpd
import matplotlib.pyplot as plt
import contextily

#disponibilité des stands

def availableDocksRate(stations_df):
    rate = 100 * stations_df.numDocksAvailable / (stations_df.numDocksAvailable + stations_df.numBikesAvailable)
    rate = rate.fillna(0)
    return rate

# disponibilité des vélos

def availableBikesRate(stations_df):
    rate = 100 * stations_df.numBikesAvailable / (stations_df.numDocksAvailable + stations_df.numBikesAvailable)
    rate = rate.fillna(0) # remplacement des NaN par des zéros
  return rate


# latest date

def getLatestDate(stations_df):
    timestamp = stations_df.last_reported.max()
    date = dt.datetime.fromtimestamp(timestamp).strftime('%d-%m-%Y %H:%M:%S')
    return date

#stats from key

def stationStatistics(stations_df_key):
    count = stations_df_key.count()
    min = stations_df_key.min()
    max = stations_df_key.max()
    mean = stations_df_key.mean()
    std = stations_df_key.std()

    stats = pd.DataFrame( {stations_df_key.name : [count, min, max, mean, std]} )
    stats.index = ['count', 'min', 'max', 'mean', 'std']
    return stats
