# FONCTIONS SPECS

import json
import time
import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt
import contextily as ctx

# disponibilité des stands

def availableDocksRate(stations_df):
	rate = 100*stations_df.numDocksAvailable / (stations_df.numDocksAvailable + stations_df.numBikesAvailable)
	rate = rate.fillna(0)
	return rate

# disponibilité des vélos

def availableBikesRate(stations_df):
	rate = 100*stations_df.numBikesAvailable / (stations_df.numDocksAvailable + stations_df.numBikesAvailable)
	rate = rate.fillna(0)
	return rate

# latestdate

def getLatestDate(stations_df):
	timestamp = stations_df.last_reported.max()
	date = dt.datetime.fromtimestamp(timestamp).strftime('%d-%m-%Y %H:%M:%S')
	return date

# stats selon la clé

def stats(df, key):
	try:
    data = df[key]
  except:
    print('La clé n\'existe pas')
    return 0
  count = data.count()
  min = data.min()
  max = data.max()
  mean = data.mean()
  std = data.std()
  dic = {'Sum':[count],'Minimum':[min],'Maximum':[max],'Mean':[mean],'Std':[std]}
  return dic

  # export to html

def exportStatistics(stats_df, filename):
	html_string = ''' {table} ''' with open('/content/drive/My Drive/Colab Notebooks/SAE15/web/data/'+filename, 'w') as f:
	f.write(html_string.format(table=stats_df.to_html()))

# export carte

def exportCityMap(geo_stations, marker_size, marker_color, title, date=None, filename=None):
	f, axes = plt.subplots(1, figsize=(15,15))
	geo_data_with_map = geo_stations.to_crs(epsg=3857)
	if (marker_size is not None and marker_color is not None):
		geo_data_with_map.plot(marker_color, markersize=marker_size, cmap="Y1OrRd", ax=axes)
	elif (marker_size is not None and marker_color is None):
		geo_data_with_map.plot(markersize=marker_size, cmap="Y1OrRd", ax=axes)
	elif (marker_size is None and marker_color is not None):
		geo_data_with_map.plot(marker_color, cmap="Y1OrRd", ax=axes)
	else:
		geo_data_with_map.plot(ax=axes)
	axes.set_axis_off()
	ctx.add_basemap(axes)
	if (date is not None):
		title = title + " ("+date+")"
		axes.set_title(title)
		if (filename is not None):
		plt.savefig('/content/drive/My Drive/Colab Notebooks/SAE15/web/data/'+filename)
		plt.show()		
